from sqlalchemy.orm import Session, joinedload
from app.models.order import Order, OrderItem
from app.schemas.order import OrderStatus
from typing import List, Optional
from datetime import datetime


class OrderRepository:
    def __init__(self, db: Session):
        self.db = db

    def create_order_with_items(self, buyer_id: str, seller_id: str, items_data: list):
        order = Order(buyer_id=buyer_id, seller_id=seller_id)
        self.db.add(order)
        self.db.flush()

        for item in items_data:
            self.db.add(
                OrderItem(
                    order_id=order.id,
                    seller_inventory_id=item["seller_inventory_id"],
                    quantity=item["quantity"],
                    price_at_purchase=item["price_at_purchase"],
                )
            )

        self.db.flush()
        return order

    def get_orders_by_buyer(self, buyer_id: str) -> List[Order]:
        return (
            self.db.query(Order)
            .filter(Order.buyer_id == buyer_id)
            .options(joinedload(Order.items))
            .order_by(Order.created_at.desc())
            .all()
        )

    def get_orders_by_seller(self, seller_id: str) -> List[Order]:
        return (
            self.db.query(Order)
            .filter(Order.seller_id == seller_id)
            .options(joinedload(Order.items))
            .order_by(Order.created_at.desc())
            .all()
        )

    def get_order_by_id(self, order_id: str) -> Optional[Order]:
        return (
            self.db.query(Order)
            .filter(Order.id == order_id)
            .options(joinedload(Order.items))
            .first()
        )

    def update_order_status(self, order: Order, new_status: OrderStatus):
        order.status = new_status.value
        order.updated_at = datetime.utcnow()
        self.db.commit()
        self.db.refresh(order)
        return order
