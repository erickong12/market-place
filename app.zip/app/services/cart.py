from collections import defaultdict
from sqlalchemy.orm import Session
from app.repository.cart import CartRepository
from app.repository.order import OrderRepository
from app.repository.inventory import SellerInventoryRepository
from app.core.exception import BusinessError


class CartService:
    def __init__(self, db: Session):
        self.db = db
        self.cart_repo = CartRepository(db)
        self.order_repo = OrderRepository(db)
        self.inventory_repo = SellerInventoryRepository(db)

    def checkout_cart(self, buyer_id: str):
        cart_items = self.cart_repo.get_cart_items(buyer_id)
        if not cart_items:
            raise BusinessError("Cart is empty")

        grouped_items = defaultdict(list)

        try:
            for item in cart_items:
                inv = self.inventory_repo.get_inventory(item.seller_inventory_id)
                if not inv or inv.stock < item.quantity:
                    raise BusinessError(
                        f"Insufficient stock for inventory {item.seller_inventory_id}"
                    )

                self.inventory_repo.update_stock(inv, item.quantity)

                grouped_items[inv.seller_id].append(
                    {
                        "seller_inventory_id": item.seller_inventory_id,
                        "quantity": item.quantity,
                        "price_at_purchase": item.price,
                    }
                )

            orders = []
            for seller_id, items in grouped_items.items():
                order = self.order_repo.create_order_with_items(
                    buyer_id, seller_id, items
                )
                orders.append(order)

            self.cart_repo.clear_cart(buyer_id)

            self.db.commit()
            return orders

        except Exception:
            self.db.rollback()
            raise
