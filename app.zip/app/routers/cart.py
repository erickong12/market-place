from fastapi import APIRouter, Depends, Request
from sqlalchemy.orm import Session
from typing import List
from app.database.session import get_db
from app.schemas.order import OrderResponse
from app.services.cart import CartService

router = APIRouter(prefix="/secured/checkout", tags=["Checkout"])


@router.post("/", response_model=List[OrderResponse])
def checkout_cart_api(request: Request, db: Session = Depends(get_db)):
    service = CartService(db)
    return service.checkout_cart(request.state.user.id)
